# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '319eb5467ed03a6877dab89aac5c6d7c9f628c033635ec2974ef1cf229e2bc3db8071f8dc0b6269f16d8bbc5816ebb677ab6f4260885c301383caa803c4c9ba0'